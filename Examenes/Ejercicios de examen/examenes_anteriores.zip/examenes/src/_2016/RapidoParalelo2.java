package _2016;

import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinPool;

public class RapidoParalelo2 extends RecursiveAction
{
	private int[] v; // vector sobre el que trabajamos
	private int iz, de;
	
	public RapidoParalelo2(int[] v, int iz, int de)
	{
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	public static void main (String arg [])
	{
		int n= 10000;

		int[] v = new int [n];
		Vector.aleatorio (v);
		Vector.mostrar (v); // antes de ordenar

		RapidoParalelo2 rapido = new RapidoParalelo2(v, 0, v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		pool.invoke(rapido);

		Vector.mostrar (v); // ordenado
	} // fin de main

	@Override
	protected void compute()
	{
		int m;
		if(de > iz)
		{
			m = particion(v, iz, de);
			
			RapidoParalelo2 left = new RapidoParalelo2(v,iz,m-1);
			RapidoParalelo2 right = new RapidoParalelo2(v,m+1,de);
			
			invokeAll(left, right);
		}
	}

	private int particion(int[] v, int iz, int de)
	{
		int i, pivote;
		intercambiar(v, (iz+de)/2, iz); // escondemos el pivote a la izquierda del vector
		
		pivote = v[iz];
		i = iz;
		for(int s = iz+1; s <= de; s++)
		{
			if(v[s] <= pivote)
			{
				i++;
				intercambiar(v,i,s);
			}
		}
		intercambiar(v, iz, i); // restituimos el pivote
		return i; // retornamos la posicion en la que se encuentra el pivote
	}

	private void intercambiar(int[] v, int pos1, int pos2)
	{
		int aux = pos1;
		v[pos1] = v[pos2];
		v[pos2] = v[aux];
	}
}
