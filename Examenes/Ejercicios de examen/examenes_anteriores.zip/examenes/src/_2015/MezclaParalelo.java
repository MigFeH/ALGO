package _2015;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class MezclaParalelo extends RecursiveAction
{
	private static final long serialVersionUID = 1L;
	
	private int []v;
	private int iz, de;
	
	public MezclaParalelo(int[] v, int iz, int de)
	{
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	public static void main (String arg [] )
	{
		int n=10;
		int[] v = generarVector(n);
		imprimirVector(v);
		
		/** Creo los objetos **/
		MezclaParalelo mezcla = new MezclaParalelo(v, 0, v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		/** Invoco al compute **/
		pool.invoke(mezcla);
		
		imprimirVector(v);
	}
	//...

	@Override
	protected void compute()
	{
		if (de>iz)
		{
			int m=(iz+de)/2;
			
			/** Creamos las instancias con las partes **/
			MezclaParalelo left = new MezclaParalelo(v,iz,m);
			MezclaParalelo right = new MezclaParalelo(v,m+1,de);
			/** Invocacion en paralelo **/
			invokeAll(left, right);
			
			combina(v,iz,m,m+1,de);
		}
	}
}
