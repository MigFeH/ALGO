package _2015;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class MezclaParalelo2 extends RecursiveAction
{
	private static final long serialVersionUID = 1L;
	
	private int [] v;
	private int iz, de;
	
	public MezclaParalelo2(int[] v, int iz, int de)
	{
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	
	
	public static void main (String arg [] ) {
		int n=10;
		int[] v = generarVector(n);
		imprimirVector(v);
		
		MezclaParalelo2 mezcla = new MezclaParalelo2(v, 0, v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		pool.invoke(mezcla);
		
		imprimirVector(v);
	}

	@Override
	protected void compute()
	{
		if (de > iz)
		{
			int m = (iz + de) / 2;
			
			MezclaParalelo2 left = new MezclaParalelo2(v,iz,m);
			MezclaParalelo2 right = new MezclaParalelo2(v,m+1,de);
			
			invokeAll(left, right);
			
			combina(v,iz,m,m+1,de);
		}
	}
	//...
}
