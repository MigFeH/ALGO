package _2015;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class MezclaParalelo3 extends RecursiveAction
{
	private static final long serialVersionUID = 1L;

	private int[] v;
	private int iz, de;
	
	public MezclaParalelo3(int[] v, int iz, int de)
	{
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	public static void main (String arg [])
	{
		int n=10;
		int[] v = generarVector(n);
		imprimirVector(v);
		
		MezclaParalelo3 mezcla = new MezclaParalelo3(v, 0, v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		pool.invoke(mezcla);
		
		imprimirVector(v);
	}
	//...

	@Override
	protected void compute()
	{
		if (de > iz)
		{
			int m = (iz + de) / 2;
			MezclaParalelo3 left = new MezclaParalelo3(v, iz, m);
			MezclaParalelo3 right = new MezclaParalelo3(v, m+1, de);
			
			invokeAll(left, right);
			
			combina(v, iz, m, m+1, de);
		}
	}
}
