package _2015;

public class Mezcla
{
	static int[] v;
	
	public static void mezcla(int[] v)
	{
		mezclarec (v, 0, v.length-1);
	}
	
	private static void mezclarec(int[] v, int iz, int de)
	{
		if (de > iz)
		{
			int m = (iz + de) / 2;
			mezclarec(v, iz, m);
			mezclarec(v, m+1, de);
			combina(v, iz, m, m+1, de);
		}
	}
	
	public static void main (String arg [])
	{
		int n=10;
		v = generarVector(n);
		mezcla(v);
		imprimirVector(v);
	}
	//...
}
