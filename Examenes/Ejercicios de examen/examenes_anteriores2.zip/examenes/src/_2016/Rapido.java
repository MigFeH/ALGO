package _2016;

public class Rapido
{
	static int[] v; // vector sobre el que trabajamos
	
	public static void main (String arg [])
	{
		int n= 10000;

		v = new int [n];
		Vector.aleatorio (v);
		Vector.mostrar (v); // antes de ordenar

		rapido(v,0,n-1);

		Vector.mostrar (v); // ordenado
	} // fin de main
	
	public static void quicksort (int[] v, int iz, int de)
	{
		int m;
		if (de>iz)
		{
			m=particion(v,iz,de);
			quicksort(v,iz,m-1);
			quicksort(v,m+1,de);
		}
	}
}
