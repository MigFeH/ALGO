package _2016;

import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinPool;

public class RapidoParalelo4 extends RecursiveAction
{
	private static final long serialVersionUID = 1L;
	
	private int[] v; // vector sobre el que trabajamos
	private int iz, de;
	
	public RapidoParalelo4(int[] v, int iz, int de)
	{
		/**
		 * Complejidad O(nlog(n)) en el mejor caso: el pivote que elegimos en cada iteracion es el 
		 * elemento central del vector, dando lugar a que en cada iteracion se generen dos particiones de tamanio
		 * n/2, formando un arbol.
		 * 
		 * Complejidad O(n^2) en el peor caso: el pivote que elegimos en cada iteracion es el primer o ultimo elemento
		 * del vector, dando lugar a que en cada iteracion se generen subvectores de tamanio n-1, originando un algoritmo
		 * D/V con sustraccion.
		 * 
		 * Complejidad O(n^2) en el caso medio.
		 * **/
		
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	public static void main (String arg [])
	{
		int n= 10000;

		int[] v = new int [n];
		Vector.aleatorio (v);
		Vector.mostrar (v); // antes de ordenar

		RapidoParalelo4 rapido = new RapidoParalelo4(v,0,v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		pool.invoke(rapido);

		Vector.mostrar (v); // ordenado
	} // fin de main

	@Override
	protected void compute()
	{
		int m;
		if(de > iz)
		{
			m = particion(v,iz,de);
			
			RapidoParalelo4 left = new RapidoParalelo4(v,iz,m-1);
			RapidoParalelo4 right = new RapidoParalelo4(v,m+1,de);
			
			invokeAll(left,right);
		}
	}

	private int particion(int[] v, int iz, int de)
	{
		int i, pivote;
		intercambiar(v,(iz+de)/2, iz); // escondemos el pivote (va a ser el elemento de la posicion central) a la izquierda del vector
		
		pivote = v[iz];
		i = iz;
		for(int s = iz+1; s <= de; s++)
		{
			if(v[s] <= pivote)
			{
				i++;
				intercambiar(v,i,s);
			}
		}
		intercambiar(v,i,iz); // restituimos el pivote con el ultimo de los menores (es el de la posicion con indice i)
		return i; // retornamos la posicion en la que se encuentra el pivote
	}

	private void intercambiar(int[] v, int i, int j)
	{
		int aux = v[i];
		v[i] = v[j];
		v[j] = aux;
	}
	
	
}
