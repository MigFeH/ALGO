package _2016;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class RapidoParalelo extends RecursiveAction
{
	private int[] v; // vector sobre el que trabajamos
	private int iz, de;
	
	public RapidoParalelo(int[] v, int iz, int de)
	{
		this.v = v;
		this.iz = iz;
		this.de = de;
	}
	
	public static void main (String arg [])
	{
		int n= 10000;

		int[] v = new int [n];
		Vector.aleatorio (v);
		Vector.mostrar (v); // antes de ordenar

		RapidoParalelo rapido = new RapidoParalelo(v, 0, v.length-1);
		ForkJoinPool pool = new ForkJoinPool();
		
		pool.invoke(rapido);
		
		Vector.mostrar (v); // ordenado
	} // fin de main

	
	@Override
	protected void compute()
	{
		int m;
		if (de>iz)
		{
			m = particion(v,iz,de);
			
			RapidoParalelo left = new RapidoParalelo(v,iz,m-1);
			RapidoParalelo right = new RapidoParalelo(v,m+1,de);
			
			invokeAll(left, right);
		}
	}
}
