package algoritmos;

public class Insercion
{
	/**
	 * Complejidad O(n) en el mejor caso: el vector esta inicialmente ordenado.
	 * Complejidad O(n^2) en el peor caso: el vector esta inicialmente inversamente ordenado.
	 * Complejidad O(n^2) en el caso medio.
	 * **/
	
	private static void insercion(int[] v)
	{
		int n = v.length;
		
		for(int i = 1; i < n; i++)
		{
			int x = v[i];
			int j = i-1;
			
			while(j >= 0 && v[j] >= x)
			{
				v[j+1] = v[j];
				j--;
			}
			v[j+1] = x;
		}
	}
	

	private static void insercion2(int[] v)
	{
		int n = v.length;
		
		for(int i = 1; i < n; i++)
		{
			int x = v[i];
			int j = i-1;
			
			while(j >= 0 && v[j] >= x) // si es mayor que el pivote, mover pivote a la izq
			{
				v[j+1] = v[j];
				j--;
			}
			v[j+1] = x;
		}
	}
	
	private static void rapido(int[] v)
	{
		rapidoRec(v,0,v.length-1);
	}


	private static void rapidoRec(int[] v, int iz, int de)
	{
		int m;
		if(de > iz)
		{
			m = particion(v,iz,de);
			rapidoRec(v,iz,m-1);
			rapidoRec(v,m+1,de);
		}
	}


	private static int particion(int[] v, int iz, int de)
	{
		int i, pivote;
		intercambiar(v,(iz+de)/2,iz); // escondemos el pivote a la izquierda del vector
		
		pivote = v[iz];
		i = iz;
		for(int s = iz+1; s <= de; s++)
		{
			if(v[s] <= pivote) // si es menor que el pivote, intercambiamos
			{
				i++;
				intercambiar(v,i,s);
			}
		}
		intercambiar(v,iz,i); // restituimos el pivote
		return i; // retornamos la posicion del pivote
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
